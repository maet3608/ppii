This folder contains the interaction networks used in the paper
"Gene Ontology-driven inference of protein-protein interactions using inducers"

For details see the paper.