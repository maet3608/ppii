This folder contains a set of files to run a larger prediction task using go2ppi.
Call "go2ppi.bat go2ppi.cfg"  to run this demo.

SC.ppi is a remake pf Park's yeast network with Uniprot accession numbers
instead of DIP indentifiers. See paper for details.

go.obo is the Gene Ontology in OBO format.

SC.anno and SC_uniprot.anno are the same and contain the GO term annotations
for all proteins in SC.ppi. In a real application those two files can differ.