This folder contains test data.
Run "go2ppi.bat test\test.cfg" to test go2ppi.

