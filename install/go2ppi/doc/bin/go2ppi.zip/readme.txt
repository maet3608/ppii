-------------------------------------------------------------------------------
                                    go2ppi						 
-------------------------------------------------------------------------------						 

see doc\index.html for documentation

also have a look at the comments within
go2ppi.bat
go2ppi.cfg
id2go.bat
gen_filters.bat

Run go2ppi.bat test\test.cfg 
to test the application. It takes only minutes.


